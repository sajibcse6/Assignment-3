<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
    if(Session::get('role')!=1) {
        echo "<script>window.location = 'index.php';</script>";
    }
?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New User</h2>
               <div class="block copyblock">

                <?php
                    if($_SERVER['REQUEST_METHOD'] == 'POST') {
                        $username = $fm->validation($_POST['username']);
                        $password = md5($_POST['password']);
                        $role = $_POST['role'];
                        $email = $_POST['email'];

                        $username = mysqli_real_escape_string($db->link, $username);
                        $password = mysqli_real_escape_string($db->link, $password);
                        $role = mysqli_real_escape_string($db->link, $role);
                        $email = mysqli_real_escape_string($db->link, $email);

                        $mailquery = "SELECT * FROM user WHERE email = '$email' LIMIT 1";
                        $mailcheck = $db->select($mailquery);

                        if(empty($username) || empty($password) || empty($role) || empty($email)) {
                            echo "<span class='error'>Field must not be empty!</span>";
                        }

                        else if($mailcheck) {
                            echo "<span class='error'>Email Already Exist!</span>";
                        }

                        else {
                            $query = "INSERT INTO user(username, password, email, role) VALUES('$username', '$password', '$email', '$role')";

                            $userinsert = $db->insert($query);
                            if($userinsert) {
                                echo "<span class='success'>User Added Successfully!</span>";
                            } else {
                                echo "<span class='error'>User Not Added!</span>";
                            }
                        }
                    }
                ?>
                 <form action="" method="post">
                    <table class="form">				
                        <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input type="text" name="username" placeholder="Enter Username..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Password</label>
                            </td>
                            <td>
                                <input type="password" name="password" placeholder="Enter Password..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" name="email" placeholder="Enter Email..." class="medium" />
                            </td>
                        </tr>
                            <td>
                                <label>Role</label>
                            </td>
                            <td>
                                <select id="select" name="role">
                                    <option>Select Role</option>
                                    <option value="1">Admin</option>
                                    <option value="2">Author</option>
                                    <option value="3">Editor</option>
                                </select>
                            </td>
                        </tr>
						<tr>
                            <td></td> 
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'?>