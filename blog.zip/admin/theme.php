<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Theme</h2>
               <div class="block copyblock">

                <?php
                    if($_SERVER['REQUEST_METHOD'] == 'POST') {
                        $theme = $_POST['theme'];
                        $theme = mysqli_real_escape_string($db->link, $theme);

                        $query = "UPDATE theme
                                 SET theme = '$theme' WHERE id = 1";
                        $themeupdate = $db->update($query);
                        if($themeupdate) {
                            echo "<span class='success'>Theme Updated Successfully!</span>";
                        } else {
                            echo "<span class='error'>Theme Not Updated!</span>";
                        }
                    }
                ?>

                <?php
                    $query = "SELECT * FROM theme WHERE id = 1";
                    $themes = $db->select($query);

                    $result = $themes->fetch_assoc();
                ?>
                <form action="" method="post">
                    <table class="form">				
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="default") echo "checked" ?> name="theme" value="default">Default
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="red") echo "checked" ?> name="theme" value="red">Red
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="green") echo "checked" ?> name="theme" value="green">Green
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="violet") echo "checked" ?> name="theme" value="violet">Violet
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="blue") echo "checked" ?> name="theme" value="blue">Blue
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="black") echo "checked" ?> name="theme" value="black">Black
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($result['theme']=="chocolate") echo "checked" ?> name="theme" value="chocolate">Chocolate
                            </td>
                        </tr>

						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Change" />
                            </td>
                        </tr>
                    </table>
                </form>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php'?>