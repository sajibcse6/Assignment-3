<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<div class="grid_10">

    <div class="box round first grid">
        <h2>View Post</h2>

    <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            echo "<script>window.location = 'postlist.php';</script>";
        }
    ?>

        <div class="block">
        <?php
            if(isset($_GET['viewid'])) {
                $viewid = $_GET['viewid'];
                $query = "SELECT * FROM post WHERE id = $viewid";
                $viewpost = $db->select($query);

                if($viewpost) {
                    while($result = $viewpost->fetch_assoc()) {

        ?>             
         <form action="" method="post" enctype="multipart/form-data">
            <table class="form">
               
                <tr>
                    <td>
                        <label>Title</label>
                    </td>
                    <td>
                        <input type="text" readonly name="title" value="<?php echo $result['title'];?>" class="medium" />
                    </td>
                </tr>
             
                <tr>
                    <td>
                        <label>Category</label>
                    </td>
                    <td>
                        <select id="select" name="cat">
                            <option><?php
                                $catid = $result['cat'];
                                $query = "SELECT * FROM category WHERE id=$catid";
                                $catname = $db->select($query);
                                if($catname) {
                                    while($catresult = $catname->fetch_assoc()) {
                                        echo $catresult['name'];
                                    }
                                }
                            ?></option>
                        </select>
                    </td>
                </tr>
           
            
                <tr>
                    <td></td>
                    <td>
                    <img style="height: 100px; width: 100px;" src="<?php echo $result['image'];?>" alt="">
                    </td>
                </tr>
                <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Content</label>
                    </td>
                    <td>
                        <textarea class="tinymce" name="body"><?php echo $result['body'];?></textarea>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Tags</label>
                    </td>
                    <td>
                        <input type="text" readonly name="tags" value="<?php echo $result['tags'];?>" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Author</label>
                    </td>
                    <td>
                        <input type="text" readonly name="author" value="<?php echo $result['author'];?>" class="medium" />
                        <input style="display: none;" type="text" readonly name="userid" value="<?php echo Session::get('id');?>" placeholder="Enter Author Name..." class="medium" />
                    </td>
                </tr>
				<tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Ok" />
                    </td>
                </tr>
            </table>
            </form>
            <?php } } }?>
        </div>
    </div>
</div>

<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>

<?php include 'inc/footer.php'; ?>