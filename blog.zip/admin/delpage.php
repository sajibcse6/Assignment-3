<?php include "../config/config.php" ?>
<?php include "../lib/Database.php" ?>
<?php include "../helpers/Format.php" ?>

<?php
    $db = new Database();
    $fm = new Format();
?>

<?php
    include "../lib/Session.php";
    Session::checkSession();
?>

<?php
	if(isset($_GET['id'])) {
		$delid = $_GET['id'];
		$query = "DELETE FROM page WHERE id = $delid";
		$deldata = $db->delete($query);

		if($deldata) {
            echo "<script>alert('Page Deleted Successfully');</script>";
            echo "<script>window.location = 'index.php';</script>";
        } else {
            echo "<script>alert('Page Not Deleted');</script>";
            echo "<script>window.location = 'index.php';</script>";
        }
	}
?>