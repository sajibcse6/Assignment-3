<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<div class="grid_10">

    <div class="box round first grid">
        <h2>Reply Message</h2>

    <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $to = $fm->validation($_POST['to']);
            $from = $fm->validation($_POST['from']);
            $subject = $fm->validation($_POST['subject']);
            $message = $fm->validation($_POST['message']);

            $to = mysqli_real_escape_string($db->link, $to);
            $from = mysqli_real_escape_string($db->link, $from);
            $subject = mysqli_real_escape_string($db->link, $subject);
            $message = mysqli_real_escape_string($db->link, $message);

            if($from=="" || $subject=="" || $message=="" || $to=="") {
                echo "<span class='error'>Field Must Not Be Empty!</span>";
            }
            else {
                $sendmail = mail($to, $subject, $message, $from);

                if ($sendmail) {
                 echo "<span class='success'>Message Send Successfully!
                 </span>";
                }
                else {
                 echo "<span class='error'>Message Not Send!</span>";
                }
            }
        }
    ?>

        <div class="block">

        <?php
            if(!isset($_GET['id']) || $_GET['id'] == NULL) {
                header("Location: inbox.php");
            }
            else {
                $id = $_GET['id'];
                $query = "SELECT * from contact WHERE id=$id";
                $contact = $db->select($query);

                if($contact) {
                    while($result = $contact->fetch_assoc()) {
        ?>

         <form action="" method="post">
            <table class="form">
               
                <tr>
                    <td>
                        <label>To</label>
                    </td>
                    <td>
                        <input type="email" readonly name="to" value="<?php echo $result['email'];?>" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>From</label>
                    </td>
                    <td>
                        <input type="email" name="from" placeholder="Enter Your Email..." class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Subject</label>
                    </td>
                    <td>
                        <input type="text" name="subject" placeholder="Enter Your Message Subject..." class="medium" />
                    </td>
                </tr>
                <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Message</label>
                    </td>
                    <td>
                        <textarea class="tinymce" name="message"></textarea>
                    </td>
                </tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Send" />
                    </td>
                </tr>
            </table>
            </form>
        <?php } } }?>
        </div>
    </div>
</div>

<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>

<?php include 'inc/footer.php'; ?>