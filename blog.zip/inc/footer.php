<div class="footersection templete clear">
	  <div class="footermenu clear">
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">About</a></li>
			<li><a href="#">Contact</a></li>
			<li><a href="#">Privacy</a></li>
		</ul>
	  </div>

		<?php
			$query = "SELECT * FROM copyright";
            $copy = $db->select($query);

            if($copy) {
                while($result = $copy->fetch_assoc()) {
		?>

		<p>&copy; <?php echo $result['note'];?> <?php echo date('Y');?></p>

		<?php } }?>
	</div>

	
<script type="text/javascript" src="js/scrolltop.js"></script>
</body>
</html>