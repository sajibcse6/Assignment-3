<?php include "inc/header.php";?>

	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<?php
				if(!isset($_GET['id']) || $_GET['id'] == NULL) {
			        header("Location: index.php");
			    }
			    else {
			        $pageid = $_GET['id'];
			    }

			    $query = "SELECT * FROM page WHERE id=$pageid";
	            $page = $db->select($query);

	            if($page) {
	                while($result = $page->fetch_assoc()) {
			?>
			<div class="about">
				<h2><?php echo $result['name'];?></h2>
				
				<?php echo $result['body'];?>
			</div>

			<?php } }?>

		</div>
		<?php include "inc/sidebar.php"; ?>
	</div>

	<?php include "inc/footer.php"; ?>