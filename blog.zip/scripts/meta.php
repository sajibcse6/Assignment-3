<?php
	    if(!isset($_GET['id']) || $_GET['id'] == NULL) {
	?>
		<title><?php echo $fm->title()."-".TITLE; ?></title>
	<?php
	    }
	    else {
	        $pageid = $_GET['id'];
	        $path = $_SERVER['SCRIPT_FILENAME'];

			if(str_contains($path, 'page')) {
	        	$query = "SELECT * FROM page WHERE id=$pageid";
	        }
	        else if(str_contains($path, 'post.php')) {
	        	$query = "SELECT * FROM post WHERE id=$pageid";
	        }

            $page = $db->select($query);

            if($page) {
                while($result = $page->fetch_assoc()) {
	?>

	<title>
	<?php
		if(str_contains($path, 'post.php')) {
			echo $result['title']."-".TITLE;
		}
		if(str_contains($path, 'page')) {
			echo $result['name']."-".TITLE;
		}
	?>
	</title>

	<?php } } }?>

	<meta name="language" content="English">
	<meta name="description" content="It is a website about education">
	<meta name="keywords" content="blog,cms blog">
	<meta name="author" content="Delowar">